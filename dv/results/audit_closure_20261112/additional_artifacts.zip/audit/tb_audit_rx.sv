`timescale 1ns/1ps
// Independent serial peer and APB oracle. No internal RX state/probes.
module tb_audit_rx;
    logic clk=0; always #10 clk=~clk;
    logic rst_n=0,sel=0,en=0,wr=0,rx=1,tx,ready,error,irq;
    logic [11:0] addr=0;
    logic [31:0] wd=0,rd;
    int checks,frames,scenarios;
    apb_uart_sv dut(.CLK(clk),.RSTN(rst_n),.PADDR(addr),.PWDATA(wd),.PWRITE(wr),
        .PSEL(sel),.PENABLE(en),.PRDATA(rd),.PREADY(ready),.PSLVERR(error),
        .rx_i(rx),.tx_o(tx),.event_o(irq));
    task automatic check(input bit ok,input string msg);
        checks++; if(!ok) $fatal(1,"AUDIT_RX_FAIL|%s|scenario=%0d",msg,scenarios);
    endtask
    task automatic apb(input bit write,input int a,input int data,output logic[31:0] value,input bit err=0);
        @(negedge clk);sel=1;en=0;wr=write;addr=12'(a);wd=32'(data);
        @(negedge clk);en=1;
        @(posedge clk);value=rd;check(ready && error==err,"APB ready/error");
        @(negedge clk);sel=0;en=0;wr=0;
    endtask
    task automatic write_reg(input int a,input int value,input bit err=0);
        logic[31:0] ignored;apb(1,a,value,ignored,err);
    endtask
    task automatic expect_reg(input int a,input int value);
        logic[31:0] actual;apb(0,a,0,actual);
        check(actual===32'(value),$sformatf("addr=%03h actual=%08h expected=%08h",a,actual,value));
    endtask
    task automatic configure(input int d,input int n,input int p,input int s,input bit fifo_on=1);
        int mode;
        @(negedge clk);rst_n=0;rx=1;sel=0;en=0;repeat(4) @(negedge clk);rst_n=1;
        mode=(n-5)|(s==2?4:0)|(p!=0?8:0)|(p==2?16:0);
        write_reg(12,mode|128);write_reg(0,d&255);write_reg(4,d>>8);
        write_reg(12,mode);write_reg(8,fifo_on?7:6);
        repeat(16*d+8) @(negedge clk);
    endtask
    task automatic peer(input byte data,input int d,input int n,input int p,input int s,
                        input real rate,input bit badparity=0,input bit[1:0] badstop=0);
        real duration;bit par;
        duration=320.0*d/rate;par=0;
        rx=0;#(duration);
        for(int k=0;k<n;k++) begin rx=data[k];par^=data[k];#(duration);end
        if(p!=0) begin rx=(p==2?par:!par)^badparity;#(duration);end
        for(int k=0;k<s;k++) begin rx=!badstop[k];#(duration);end
        rx=1;frames++;
    endtask
    initial begin
        real rates[3]='{0.98,1.0,1.02};
        int d;
        logic[31:0] value;
        // D=1: all formats, every integer-ns phase, both tolerance limits,
        // two consecutive frames without inserted idle.
        for(int n=5;n<=8;n++) for(int p=0;p<3;p++) for(int s=1;s<=2;s++)
        foreach(rates[r]) for(int ph=0;ph<20;ph++) begin
            configure(1,n,p,s);#(ph);
            peer('h96,1,n,p,s,rates[r]);peer('h69,1,n,p,s,rates[r]);
            repeat(20) @(negedge clk);
            expect_reg(20,'h61);expect_reg(0,'h96&((1<<n)-1));
            expect_reg(0,'h69&((1<<n)-1));expect_reg(20,'h60);scenarios++;
        end
        $display("AUDIT_STAGE|min_divisor_matrix|scenarios=%0d|frames=%0d",scenarios,frames);
        // RX extreme counter and long formats, including 12-bit frames.
        for(int idx=0;idx<2;idx++) begin
            d=idx==0?326:65535;
            foreach(rates[r]) begin
                configure(d,8,2,2);#19;
                peer('ha6,d,8,2,2,rates[r]);peer('h59,d,8,2,2,rates[r]);
                repeat(20) @(negedge clk);
                expect_reg(20,'h61);expect_reg(0,'ha6);expect_reg(0,'h59);expect_reg(20,'h60);scenarios++;
            end
        end
        // Independent counterpart of the UVM early-read reproduction.
        configure(27,8,0,1);
        fork
            peer('ha5,27,8,0,1,1.0);
            begin #(156.0*27.0*20.0);expect_reg(20,'h61);expect_reg(0,'ha5);end
        join
        expect_reg(20,'h60);scenarios++;
        $display("AUDIT_STAGE|early_rbr_after_completion|PASS");
        // Exercise every invalid WRITE address and show that divisor/config
        // remain intact. The repository sweep covered every invalid READ.
        configure(2,8,0,1);write_reg(12,'h83);
        for(int a=0;a<4096;a++) if(!(a inside {0,4,8,12,20})) write_reg(a,'hffffffff,1);
        expect_reg(12,'h83);expect_reg(0,2);expect_reg(4,0);expect_reg(8,'hc1);expect_reg(20,'h60);
        $display("AUDIT_STAGE|4091_invalid_writes|PASS");
        $display("AUDIT_RX_COMPLETED|checks=%0d|scenarios=%0d|frames=%0d",checks,scenarios,frames);$finish;
    end
    initial begin #2_000_000_000; $fatal(1,"AUDIT_RX_WATCHDOG");end
endmodule
