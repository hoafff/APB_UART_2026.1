`timescale 1ns/1ps
module tb_audit_fifo;
    logic clk=0;always #10 clk=~clk;
    logic rst_n=0,clear_i=0,push=0,pop=0,ack=0,po,qo,err;
    logic[4:0] cap=16,count,next_count;
    logic[10:0] data=0,head;
    bit[10:0] model[$],discard;
    int checks,steps;
    int unsigned rng=32'h20261112;
    uart_fifo #(.WIDTH(11)) dut(.clk(clk),.rst_n(rst_n),.clear_i(clear_i),.capacity_i(cap),
        .push_i(push),.pop_i(pop),.ack_error_i(ack),.data_i(data),.data_o(head),
        .push_ok_o(po),.pop_ok_o(qo),.any_error_o(err),.count_o(count),.next_count_o(next_count));
    function automatic int unsigned random_word();
        rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;
    endfunction
    task automatic check(input bit ok,input string msg);
        checks++;if(!ok)$fatal(1,"AUDIT_FIFO_FAIL|step=%0d|%s",steps,msg);
    endtask
    task automatic step(input bit p,input bit q,input bit a,input bit c,input bit[10:0] value);
        bit pop_ok,push_ok,anyerr;
        @(negedge clk);push=p;pop=q;ack=a;clear_i=c;data=value;
        pop_ok=q && model.size()!=0 && !c;
        push_ok=p && (model.size()<cap || pop_ok) && !c;
        #1;check(qo==pop_ok && po==push_ok,"handshake");
        if(c)model.delete();
        else begin
            if(a && model.size())model[0]&=11'h0ff;
            if(pop_ok)discard=model.pop_front();
            if(push_ok)model.push_back(value);
        end
        @(posedge clk);#1;
        anyerr=0;foreach(model[k])anyerr|=(model[k][10:8]!=0);
        check(count==model.size(),"count");
        check(head==(model.size()?model[0]:0),"head data/metadata");
        check(err==anyerr,"all-entry error summary");steps++;
    endtask
    initial begin
        repeat(3)@(negedge clk);rst_n=1;
        for(int mode=0;mode<2;mode++) begin
            cap=mode==0?1:16;step(0,0,0,1,0);
            // Each occupancy and simultaneous request/ack combination.
            for(int occ=0;occ<=cap;occ++)for(int bits=0;bits<16;bits++)begin
                step(0,0,0,1,0);
                repeat(occ)step(1,0,0,0,11'(random_word()));
                step(bits[0],bits[1],bits[2],bits[3],11'(random_word()));
            end
            repeat(15000)begin
                int unsigned v;v=random_word();
                step(v[0],v[1],v[2],(v[8:3]==0),11'(v>>9));
            end
        end
        $display("AUDIT_FIFO_COMPLETED|seed=0x20261112|steps=%0d|checks=%0d",steps,checks);$finish;
    end
endmodule
