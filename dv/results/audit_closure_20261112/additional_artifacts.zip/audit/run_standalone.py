from pathlib import Path
import subprocess,sys,json,time,hashlib
audit=Path(__file__).resolve().parent
repo=audit.parent/'APB_UART_2026.1'
sys.path.insert(0,str(repo/'tools'))
from run_dv import command
name=sys.argv[1]
top='tb_audit_'+name
files=[repo/p for p in (repo/'rtl/modified/pulp_apb_uart_sv/files.f').read_text().splitlines()]
files.append(audit/(top+'.sv'))
out=audit/('standalone_'+name);out.mkdir(exist_ok=True)
cmd=command('verilator')+['--binary','--timing','--assert','-Wno-fatal','--top-module',top,
    '--Mdir',str(out/'obj'),'-j','1']+list(map(str,files))
meta={'seed':'0x20261112' if name=='fifo' else 'deterministic',
    'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'build_command':cmd}
start=time.monotonic()
with (out/'build.log').open('w') as f:
    p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
meta['build_rc']=p.returncode
if p.returncode==0:
    run=command('verilator')[:-1]+[str(out/'obj'/('V'+top))]
    meta['run_command']=run
    with (out/'run.log').open('w') as f:
        p=subprocess.run(run,cwd=out,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    meta['run_rc']=p.returncode
    meta['raw_output']=(out/'run.log').read_text()
meta['seconds']=time.monotonic()-start
(out/'result.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))
raise SystemExit(p.returncode)
